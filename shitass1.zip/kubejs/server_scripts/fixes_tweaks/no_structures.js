/**
 * Remove the stronghold biome tag so that there are no biomes that can generate strongholds
 * The same is done for Ad Astra's moon dungeons and Oil wells (contain unused materials)
 */
ServerEvents.tags("worldgen/biome", event => {
    event.removeAll("ad_astra:has_structure/moon_dungeon");
    event.removeAll("ad_astra:has_structure/oil_well");
});
